
const loader=document.getElementById('loader');
window.addEventListener('load',()=>setTimeout(()=>loader?.classList.add('hidden'),450));

const header=document.getElementById('siteHeader');
window.addEventListener('scroll',()=>header?.classList.toggle('scrolled',window.scrollY>110));

const toggle=document.getElementById('menuToggle');
const menu=document.getElementById('navMenu');
toggle?.addEventListener('click',()=>{
  const open=menu.classList.toggle('open');
  toggle.setAttribute('aria-expanded',String(open));
  document.body.classList.toggle('menu-open',open);
});
document.querySelectorAll('.nav-menu a').forEach(a=>a.addEventListener('click',()=>{
  menu?.classList.remove('open');document.body.classList.remove('menu-open');toggle?.setAttribute('aria-expanded','false');
}));

const io=new IntersectionObserver(entries=>entries.forEach(e=>{
  if(e.isIntersecting){e.target.classList.add('visible');io.unobserve(e.target)}
}),{threshold:.12});
document.querySelectorAll('.reveal').forEach(el=>io.observe(el));

let lang=localStorage.getItem('zenith-lang')||'fr';
function setLang(next){
  lang=next;localStorage.setItem('zenith-lang',lang);document.documentElement.lang=lang;
  document.querySelectorAll('[data-fr][data-en]').forEach(el=>el.textContent=el.dataset[lang]);
  document.querySelectorAll('.lang-btn').forEach(b=>b.classList.toggle('active',b.dataset.lang===lang));
}
document.querySelectorAll('.lang-btn').forEach(b=>b.addEventListener('click',()=>setLang(b.dataset.lang)));
setLang(lang);
document.querySelectorAll('#year').forEach(el=>el.textContent=new Date().getFullYear());

const toast=document.getElementById('toast');
function showToast(message,error=false){
  if(!toast)return;
  toast.textContent=message;
  toast.classList.toggle('error',error);
  toast.classList.add('show');
  setTimeout(()=>toast.classList.remove('show'),4200);
}

const form=document.getElementById('quoteForm');
form?.addEventListener('submit',async(e)=>{
  e.preventDefault();
  const button=document.getElementById('submitQuote');
  const fd=new FormData(form);
  const payload=Object.fromEntries(fd.entries());
  payload.language=lang;

  if(payload.company) return; // honeypot
  button.disabled=true;
  button.textContent=lang==='fr'?'Envoi en cours…':'Sending…';

  try{
    const res=await fetch('/api/quote',{
      method:'POST',
      headers:{'Content-Type':'application/json'},
      body:JSON.stringify(payload)
    });
    const data=await res.json();
    if(!res.ok) throw new Error(data.error||'Request failed');
    form.reset();
    showToast(lang==='fr'
      ?'Merci. Votre demande a été reçue. Notre équipe vous contactera.'
      :'Thank you. Your request has been received. Our team will contact you.');
  }catch(err){
    showToast(lang==='fr'
      ?'Impossible d’envoyer la demande pour le moment. Veuillez nous appeler ou nous écrire.'
      :'Unable to send the request right now. Please call or email us.',true);
  }finally{
    button.disabled=false;
    button.textContent=lang==='fr'?'Envoyer la demande':'Send Request';
  }
});
