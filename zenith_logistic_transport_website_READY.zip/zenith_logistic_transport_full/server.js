
const express = require('express');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
require('dotenv').config();

const app = express();
const PORT = process.env.PORT || 3000;
const publicDir = path.join(__dirname, 'public');
const dataDir = path.join(__dirname, 'data');
const leadsFile = path.join(dataDir, 'leads.json');

fs.mkdirSync(dataDir, { recursive: true });
if (!fs.existsSync(leadsFile)) fs.writeFileSync(leadsFile, '[]');

app.use(express.json({ limit: '200kb' }));
app.use(express.urlencoded({ extended: true }));
app.use(express.static(publicDir, {
  maxAge: process.env.NODE_ENV === 'production' ? '1h' : 0
}));

function clean(value, max=1000) {
  return String(value || '').replace(/[<>]/g, '').trim().slice(0, max);
}
function validEmail(v){ return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v); }

async function sendEmail(lead) {
  const { SMTP_HOST, SMTP_PORT, SMTP_USER, SMTP_PASS, SMTP_TO } = process.env;
  if (!SMTP_HOST || !SMTP_USER || !SMTP_PASS) return { sent:false, reason:'SMTP not configured' };

  const nodemailer = require('nodemailer');
  const transporter = nodemailer.createTransport({
    host: SMTP_HOST,
    port: Number(SMTP_PORT || 587),
    secure: String(process.env.SMTP_SECURE || 'false') === 'true',
    auth: { user: SMTP_USER, pass: SMTP_PASS }
  });

  const to = SMTP_TO || 'zenithlogistics9@gmail.com';
  await transporter.sendMail({
    from: process.env.SMTP_FROM || SMTP_USER,
    to,
    replyTo: lead.email,
    subject: `New Zenith quote request — ${lead.service}`,
    text:
`New website quote request

Reference: ${lead.reference}
Name: ${lead.name}
Phone: ${lead.phone}
Email: ${lead.email}
Service: ${lead.service}
Origin: ${lead.origin}
Destination: ${lead.destination}
Language: ${lead.language}

Message:
${lead.message}
`
  });
  return { sent:true };
}

app.post('/api/quote', async (req, res) => {
  try {
    const body = req.body || {};
    if (body.company) return res.status(200).json({ ok:true }); // bot honeypot

    const lead = {
      reference: 'ZLT-' + crypto.randomBytes(4).toString('hex').toUpperCase(),
      createdAt: new Date().toISOString(),
      name: clean(body.name, 120),
      phone: clean(body.phone, 60),
      email: clean(body.email, 160),
      service: clean(body.service, 120),
      origin: clean(body.origin, 160),
      destination: clean(body.destination, 160),
      language: body.language === 'en' ? 'en' : 'fr',
      message: clean(body.message, 4000)
    };

    if (!lead.name || !lead.phone || !lead.email || !lead.service || !lead.message) {
      return res.status(400).json({ error: 'Missing required fields' });
    }
    if (!validEmail(lead.email)) {
      return res.status(400).json({ error: 'Invalid email' });
    }

    const leads = JSON.parse(fs.readFileSync(leadsFile, 'utf8'));
    leads.push(lead);
    fs.writeFileSync(leadsFile, JSON.stringify(leads, null, 2));

    let email = { sent:false };
    try { email = await sendEmail(lead); } catch (e) { console.error('Email error:', e.message); }

    res.status(201).json({ ok:true, reference:lead.reference, emailSent:email.sent });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error:'Server error' });
  }
});

app.get('/api/health', (_req,res)=>res.json({ ok:true, service:'Zenith Logistic Transport website' }));

app.use((_req,res)=>res.status(404).sendFile(path.join(publicDir,'404.html')));

app.listen(PORT, () => console.log(`Zenith website running on http://localhost:${PORT}`));
