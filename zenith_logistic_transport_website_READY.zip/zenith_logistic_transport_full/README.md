# Zenith Logistic Transport — Full Functional Website

This package is a production-style full-stack website for Zenith Logistic Transport.

## What is included
- French-first bilingual FR/EN website
- Official Zenith logo
- Cinematic animated homepage
- About page
- Services index
- 7 dedicated service pages
- Ghana / Burkina Faso / international network page
- Contact + quote page
- Fully responsive mobile navigation
- Persistent language preference
- Quote form with a real backend endpoint
- Quote requests saved to `data/leads.json`
- Optional SMTP email notification using Nodemailer
- Anti-bot honeypot field
- Basic server-side validation
- 404 page
- Health-check API endpoint
- WhatsApp shortcut configured to +233 53 286 1102
- Direct phone and email links

## Run locally

1. Install Node.js 18+.
2. Open a terminal in this folder.
3. Run:
   npm install
4. Copy `.env.example` to `.env`.
5. Run:
   npm start
6. Open:
   http://localhost:3000

## Quote requests

Every valid form submission is stored in:
`data/leads.json`

The API endpoint is:
`POST /api/quote`

A health endpoint is available at:
`GET /api/health`

## Email delivery

The site works without SMTP: leads are still stored locally.

To also email each quote request to Zenith, fill in the SMTP settings in `.env`.

For Gmail, use an App Password rather than your normal Gmail password.

## Production deployment

This Node/Express site can be deployed on platforms that support Node.js, such as:
- Render
- Railway
- Fly.io
- VPS hosting
- Any Node-capable hosting provider

For static-only hosting, the front-end pages will load, but `/api/quote` will require a serverless function or external form provider.

## Important media note

The current cinematic photos load from Unsplash URLs. Before final public launch, replace them with approved local brand photography/video files for maximum reliability, speed and brand control.

## WhatsApp

The floating WhatsApp button currently points to:
+233 53 286 1102

If a different number should be used for WhatsApp, change the `wa.me` link in the shared footer markup of the HTML files.

## Contact information used
- Email: zenithlogistics9@gmail.com
- Phone: +233 53 286 1102
- Phone: +233 56 193 2005
- Address: Meridian Plaza, Community One, Tema, Ghana
